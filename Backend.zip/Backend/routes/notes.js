const express = require('express')
const router = express.Router()
const fetchUser = require('../middleware/fetchUser')
const Note = require("../models/Note");
const { body, validationResult } = require('express-validator');

// ROUTE - 1 : Get all the notes using GET "/api/notes/fetchallnotes",  require authentication
router.get('/fetchallnotes', fetchUser, async (req, res) => {
    try {
        const notes = await Note.find({ user: req.user.id })
        res.json(notes)
    } catch (error) {
        if (error.code === 11000) {
            // Duplicate key error
            return res.status(400).json({ error: 'Email already exists' });
        }
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }

})

// ROUTE - 2 : Send the notes using POST "/api/notes/addnote",  require authentication
router.post('/addnote', fetchUser, [
    body('title', 'Enter a valid title').isLength({ min: 3 }),
    body('description', "Enter a valid description").isLength({ min: 5 }),
], async (req, res) => {
    try {
        // const { title, description, tag } = req.body
        // If there are errors, it returns Bad Request and displays the error
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const note = new Note({
            title: req.body.title,
            description: req.body.description,
            tag: req.body.tag,
            user: req.user.id
        })
        const savedNote = await note.save()
        res.json(savedNote)
    } catch (error) {
        if (error.code === 11000) {
            // Duplicate key error
            return res.status(400).json({ error: 'Email already exists' });
        }
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }

})

module.exports = router

// const express = require('express');
// const router = express.Router();
// const fetchuser = require('../middleware/fetchUser');
// const Note = require('../models/Note');
// const { body, validationResult } = require('express-validator');

// // ROUTE 1: Get All the Notes using: GET "/api/auth/getuser". Login required
// router.get('/fetchallnotes', fetchuser, async (req, res) => {
//     try {
//         const notes = await Note.find({ user: req.user.id });
//         res.json(notes)
//     } catch (error) {
//         console.error(error.message);
//         res.status(500).send("Internal Server Error");
//     }
// })

// // ROUTE 2: Add a new Note using: POST "/api/auth/addnote". Login required
// router.post('/addnote', fetchuser, [
//     body('title', 'Enter a valid title').isLength({ min: 3 }),
//     body('description', 'Description must be atleast 5 characters').isLength({ min: 5 }),], async (req, res) => {
//         try {

//             const { title, description, tag } = req.body;

//             // If there are errors, return Bad request and the errors
//             const errors = validationResult(req);
//             if (!errors.isEmpty()) {
//                 return res.status(400).json({ errors: errors.array() });
//             }
//             const note = new Note({
//                 title, description, tag, user: req.user.id
//             })
//             const savedNote = await note.save()

//             res.json(savedNote)

//         } catch (error) {
//             console.error(error.message);
//             res.status(500).send("Internal Server Error");
//         }
//     })

// module.exports = router